
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGameLibrary.Graphics;
using MonoGameLibrary.Physics;

namespace The_ancient_s_wizard_dungeon
{
    public class Enemigos
    {
        private List<Erizo> _erizos = new List<Erizo>();

         public IReadOnlyList<Erizo> Erizos => _erizos;

        private int _siguienteId = 1;

        public void AgregarErizo(TextureRegion sprite, Vector2 posicion)
        {
            Erizo nuevoErizo = new Erizo(
                _siguienteId,
                sprite,
                posicion
            );

            _erizos.Add(nuevoErizo);

            _siguienteId++;
        }

        public void DibujarErizos(SpriteBatch spriteBatch)
        {
            foreach (Erizo erizo in _erizos)
            {
                erizo.Dibujar(spriteBatch);
            }
        }
        public void AgregarCuerposVivos(List<CollisionBody> cuerpos)
{
    foreach (Erizo erizo in _erizos)
    {
        if (erizo.EstaVivo)
        {
            cuerpos.Add(erizo.Cuerpo);
        }
    }
}
        public void ActualizarErizos(
    GameTime gameTime,
    Jugador jugador1,
    Jugador jugador2,
    int numeroJugadores,
    CollisionBody cuerpoRana,
    bool ranaViva,
    Rectangle limitesMapa)
        {
            foreach (Erizo erizo in _erizos)
            {
                erizo.Actualizar(
                    gameTime,
                    jugador1,
                    jugador2,
                    numeroJugadores,
                    cuerpoRana,
                    ranaViva,
                    limitesMapa
                );
            }
        }
    }
}
