﻿using var game = new The_ancient_s_wizard_dungeon.Game1();
game.Run();
