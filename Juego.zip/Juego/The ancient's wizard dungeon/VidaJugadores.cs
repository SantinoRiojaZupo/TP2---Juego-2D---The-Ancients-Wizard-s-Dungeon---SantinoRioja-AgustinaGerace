
using Microsoft.Xna.Framework.Graphics;
using MonoGameLibrary.Graphics;
//using Microsoft.Xna.Framework;

public class VidaJugadores
{
    private TextureRegion corazonLleno;
    private TextureRegion medioCorazon;
    private TextureRegion corazonVacio;

   // private int vidasJugador1 = 8;
    //private int vidasJugador2 = 8;

    public VidaJugadores(Texture2D textura)
    {
        // Regiones de los tres corazones de la imagen
        corazonLleno = new TextureRegion(textura, 9, 8, 64, 64);
        medioCorazon = new TextureRegion(textura, 176, 13, 72, 60);
        corazonVacio = new TextureRegion(textura, 336, 13, 72, 60);
    }
}
   /* public void Dibujar(SpriteBatch spriteBatch, int numeroJugadores)
    {
        DibujarVidas(spriteBatch, vidasJugador1, 10, 10);

        if (numeroJugadores == 2)
            DibujarVidas(spriteBatch, vidasJugador2, 10, 45);
    }

    private void DibujarVidas(SpriteBatch spriteBatch, int vidas, int x, int y)
    {
        for (int i = 0; i < 4; i++)
        {
            TextureRegion corazon;

            if (vidas >= 2)
                corazon = corazonLleno;
            else if (vidas == 1)
                corazon = medioCorazon;
            else
                corazon = corazonVacio;

            corazon.Draw(
                spriteBatch,
                new Vector2(x + i * 38, y),
                Color.White,
                0f,
                Vector2.Zero,
                new Vector2(0.5f, 0.5f),
                SpriteEffects.None,
                0f
            );

            vidas -= 2;
            if (vidas < 0)
                vidas = 0;
        }
    }
}
*/
