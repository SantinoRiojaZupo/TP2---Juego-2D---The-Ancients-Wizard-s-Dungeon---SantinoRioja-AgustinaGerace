﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGameLibrary;
using MonoGameLibrary.Graphics;

namespace The_ancient_s_wizard_dungeon;

//dotnet mgcb-editor ./Content/Content.mgcb

public class Game1 : Core
{

//estados del juego
private enum EstadoJuego
    {
        MenuPrincipal,
        SeleccionJugadores,
        Jugando
    }

private EstadoJuego _estadoActual = EstadoJuego.MenuPrincipal;
    private Texture2D pantallaInicial;
    private Texture2D heroe1Texture;
    private Texture2D heroe2Texture;

//botones
    private Texture2D _botonesTexture;
    private TextureRegion _regionBotonIniciar;
    private TextureRegion _regionBoton1Jugador;
    private TextureRegion _regionBoton2Jugadores;

    private Tilemap _tileMap;

  private int _numeroJugadores = 1;
private int _opcionSeleccionada = 0;
    private KeyboardState _tecladoAnterior;


  //donde aparecen los jugadores
  private Vector2 _posicionHeroe1;
    private Vector2 _posicionHeroe2;
    private float velocidad = 2.0f;

//boton para iniciar
    private Rectangle _botonIniciarRect = new Rectangle(250, 420, 300, 60);

    // seleccionar jugadores
    private Rectangle _boton1JugadorRect = new Rectangle(250, 220, 300, 60);
    private Rectangle _boton2JugadoresRect = new Rectangle(250, 310, 300, 60);

    // Textura de 1x1 píxel para pintar formas y botones sólidos
   
    public Game1() : base("The ancien's wizard dungeon", 800, 600, false)
    {

    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        base.Initialize();
    }



      protected override void LoadContent()
    {
        // TODO: use this.Content to load your game content here

base.LoadContent();

//cargamos las texturas del content
 pantallaInicial = Content.Load<Texture2D>("PantallaInicial");
        heroe1Texture = Content.Load<Texture2D>("heroe1");
        heroe2Texture = Content.Load<Texture2D>("heroe2");
        _botonesTexture = Content.Load<Texture2D>("botones");

        // definimos regiones (TextureRegion toma: Texture, X, Y, Ancho, Alto)

        _regionBotonIniciar = new TextureRegion(_botonesTexture, 0, 0, 57, 11);
        _regionBoton1Jugador = new TextureRegion(_botonesTexture, 0, 14, 57, 11);
        _regionBoton2Jugadores = new TextureRegion(_botonesTexture, 0, 27, 57, 11);



        int anchoBotonEscalado = 57 * 4;
        int altoBotonEscalado = 11 * 4;
        int posXCentrada = (Window.ClientBounds.Width - anchoBotonEscalado) / 2;

        _botonIniciarRect = new Rectangle(posXCentrada, 420, anchoBotonEscalado, altoBotonEscalado);
        _boton1JugadorRect = new Rectangle(posXCentrada, 220, anchoBotonEscalado, altoBotonEscalado);
        _boton2JugadoresRect = new Rectangle(posXCentrada, 310, anchoBotonEscalado, altoBotonEscalado);

//cargamos todos los mapas xml
  _tileMap = Tilemap.FromFile(Content, "Levels/Level1.xml");

  // posicion heroes
        _posicionHeroe1 = new Vector2(100, 100);
        _posicionHeroe2 = new Vector2(140, 100);    
        
        // escalamos el mapa para que sea mas grande ya que sino tienen que ser muchas baldosas
        _tileMap.Scale = new Vector2(2f, 2f);

     
    }

    protected override void Update(GameTime gameTime)   
    {
var tecladoActual = Keyboard.GetState();

        if (tecladoActual.IsKeyDown(Keys.Escape))
        {
            Exit();
        }
        switch (_estadoActual)
        {
            
            case EstadoJuego.MenuPrincipal:
                
               if ((tecladoActual.IsKeyDown(Keys.Enter) && _tecladoAnterior.IsKeyUp(Keys.Enter)) ||
                    (tecladoActual.IsKeyDown(Keys.Space) && _tecladoAnterior.IsKeyUp(Keys.Space)))
                {
                    _estadoActual = EstadoJuego.SeleccionJugadores;
                    _tecladoAnterior = tecladoActual;
                }
                break;

            case EstadoJuego.SeleccionJugadores:
                //  1 Jugador
               if ((tecladoActual.IsKeyDown(Keys.Up) && _tecladoAnterior.IsKeyUp(Keys.Up)) ||
                    (tecladoActual.IsKeyDown(Keys.W) && _tecladoAnterior.IsKeyUp(Keys.W)))
                {
                   _numeroJugadores=1;
                    _opcionSeleccionada =0;
                    _tecladoAnterior = tecladoActual;
                   
                }
                //  2 Jugadores
               if ((tecladoActual.IsKeyDown(Keys.Down) && _tecladoAnterior.IsKeyUp(Keys.Down)) ||
                    (tecladoActual.IsKeyDown(Keys.S) && _tecladoAnterior.IsKeyUp(Keys.S)))
                {
                    _numeroJugadores=2;
                     _opcionSeleccionada =1;
                     _tecladoAnterior = tecladoActual;
                }
               if ((tecladoActual.IsKeyDown(Keys.Enter) && _tecladoAnterior.IsKeyUp(Keys.Enter)) ||
            (tecladoActual.IsKeyDown(Keys.Space) && _tecladoAnterior.IsKeyUp(Keys.Space)))
                {
                    _estadoActual = EstadoJuego.Jugando;
                }

                
                break;

            case EstadoJuego.Jugando:

                //ACA VA A IR LA LOGICA CUANDO ESTES JUGANDO
                if (tecladoActual.IsKeyDown(Keys.A))
                {
                    _posicionHeroe1.X = _posicionHeroe1.X -velocidad;
                }
                 if (tecladoActual.IsKeyDown(Keys.S))
                {
                    _posicionHeroe1.Y = _posicionHeroe1.Y +velocidad;
                }
                 if (tecladoActual.IsKeyDown(Keys.D))
                {
                    _posicionHeroe1.X = _posicionHeroe1.X +velocidad;
                }
                 if (tecladoActual.IsKeyDown(Keys.W))
                {
                    _posicionHeroe1.Y = _posicionHeroe1.Y -velocidad;
                }
                 if (tecladoActual.IsKeyDown(Keys.Left))
                {
                    _posicionHeroe2.X = _posicionHeroe2.X -velocidad;
                }
                 if (tecladoActual.IsKeyDown(Keys.Down))
                {
                    _posicionHeroe2.Y = _posicionHeroe2.Y +velocidad;
                }
                 if (tecladoActual.IsKeyDown(Keys.Right))
                {
                    _posicionHeroe2.X = _posicionHeroe2.X +velocidad;
                }
                 if (tecladoActual.IsKeyDown(Keys.Up))
                {
                    _posicionHeroe2.Y = _posicionHeroe2.Y -velocidad;
                }


                break;
        }
        // TODO: Add your update logic here

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);


            // Begin the sprite batch to prepare for rendering.
    SpriteBatch.Begin();

        if (_estadoActual == EstadoJuego.MenuPrincipal)
        {
            

//tamaño de la pantalla inicial escalado a la pantalla del juego
        float escalaXTitulo = (float)Window.ClientBounds.Width / pantallaInicial.Width;
    float escalaYTitulo = (float)Window.ClientBounds.Height / pantallaInicial.Height;
SpriteBatch.Draw(
                pantallaInicial,                        
                Vector2.Zero,           
                null,                     
                Color.White,                
                0,   
                Vector2.Zero,               
                new Vector2(escalaXTitulo, escalaYTitulo),
                SpriteEffects.None,         
                0.0f                        
            );
            
            
            _regionBotonIniciar.Draw(
                SpriteBatch, 
                new Vector2(_botonIniciarRect.X, _botonIniciarRect.Y), 
                Color.Gold,
                0f,
                Vector2.Zero,
                new Vector2(4f, 4f),
                SpriteEffects.None,
                0f
            );
        }

        else if (_estadoActual==EstadoJuego.SeleccionJugadores)
        {
            
           GraphicsDevice.Clear(Color.DarkSlateGray);

            // El botón activo se pinta de Gold, el inactivo de White
            Color colorBoton1 = (_opcionSeleccionada == 0) ? Color.Gold : Color.White;
            Color colorBoton2 = (_opcionSeleccionada == 1) ? Color.Gold : Color.White;

            _regionBoton1Jugador.Draw(
                SpriteBatch, 
                new Vector2(_boton1JugadorRect.X, _boton1JugadorRect.Y), 
                colorBoton1,
                0f,
                Vector2.Zero,
                new Vector2(4f, 4f),
                SpriteEffects.None,
                0f
            );

            _regionBoton2Jugadores.Draw(
                SpriteBatch, 
                new Vector2(_boton2JugadoresRect.X, _boton2JugadoresRect.Y), 
                colorBoton2,
                0f,
                Vector2.Zero,
                new Vector2(4f, 4f),
                SpriteEffects.None,
                0f
            );
            
        }
        else if( _estadoActual == EstadoJuego.Jugando)
        {
          _tileMap.Draw(SpriteBatch);

            // Dibujamos héroes
            SpriteBatch.Draw(heroe1Texture, _posicionHeroe1, Color.White);
           
            if (_numeroJugadores == 2)
            {
                SpriteBatch.Draw(heroe2Texture, _posicionHeroe2, Color.White);
            }
        }

    // Always end the sprite batch when finished.
    SpriteBatch.End();

        base.Draw(gameTime);
    }
}
