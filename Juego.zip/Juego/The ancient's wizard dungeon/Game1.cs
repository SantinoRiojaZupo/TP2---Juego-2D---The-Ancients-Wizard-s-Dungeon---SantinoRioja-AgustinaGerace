﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGameLibrary;
using MonoGameLibrary.Graphics;

namespace The_ancient_s_wizard_dungeon;

public class Game1 : Core
{

    private Texture2D pantallaInicial;
    private Tilemap _tileMap;
    private bool _jugando = false; // Para alternar entre la pantalla inicial y el mapa de juego
    public Game1() : base("The ancien's wizard dungeon", 800, 600, false)
    {

    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        base.Initialize();
    }



      protected override void LoadContent()
    {
        // TODO: use this.Content to load your game content here

base.LoadContent();

  pantallaInicial = Content.Load<Texture2D>("PantallaInicial");

  _tileMap = Tilemap.FromFile(Content, "Levels/Level1.xml");
        
        // Escalamos el mapa un poco para que se vea más grande en pantalla (opcional)
        _tileMap.Scale = new Vector2(2f, 2f);
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();


// Ejemplo simple: Presionar Enter o Espacio para pasar de la pantalla inicial al juego
        var keyboardState = Keyboard.GetState();
        if (!_jugando && (keyboardState.IsKeyDown(Keys.Enter) || keyboardState.IsKeyDown(Keys.Space)))
        {
            _jugando = true;
        }
        // TODO: Add your update logic here

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);


            // Begin the sprite batch to prepare for rendering.
    SpriteBatch.Begin();
        if (_jugando != true)
        {
            

//tamaño de la pantalla inicial escalado a la pantalla del juego
        float escalaXTitulo = (float)Window.ClientBounds.Width / pantallaInicial.Width;
    float escalaYTitulo = (float)Window.ClientBounds.Height / pantallaInicial.Height;
    // Draw the texture.
    SpriteBatch.Draw(
        pantallaInicial,                      // texture
         Vector2.Zero,            // position
        null,                       // sourceRectangle
        Color.White,                // color
        0,   // rotation
        Vector2.Zero,               // origin
        new Vector2(escalaXTitulo, escalaYTitulo),// scale
        SpriteEffects.None,         // effects
        0.0f                        // layerDepth
    );
        }

        else
        {
            // ¡Dibujamos el Tilemap de la mazmorra cuando comience la acción!
            _tileMap.Draw(SpriteBatch);
        }

    // Always end the sprite batch when finished.
    SpriteBatch.End();

        base.Draw(gameTime);
    }
}
