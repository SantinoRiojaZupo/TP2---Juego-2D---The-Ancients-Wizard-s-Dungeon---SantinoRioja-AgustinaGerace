﻿//using System.Numerics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGameLibrary;
using MonoGameLibrary.Graphics;
using System.Collections.Generic;

namespace The_ancient_s_wizard_dungeon;
//cd '.\Juego\The ancient''s wizard dungeon\'
//despues
//dotnet mgcb-editor ./Content/Content.mgcb

public class Game1 : Core
{

    //estados del juego
    private enum EstadoJuego
    {
        MenuPrincipal,
        SeleccionJugadores,
        Jugando
    }
    private Tilemap _tileMap;
    private Rectangle limitesMapa = new Rectangle(0, 0, 800, 600);

    private EstadoJuego _estadoActual = EstadoJuego.MenuPrincipal;
    private Texture2D pantallaInicial;
    private Texture2D principe1_spritesheetTexture;
    private Texture2D principe2_spritesheetTexture;
    private Texture2D _ErizoSpriteSheetTexture;
    private Texture2D _ranaSpriteSheetTexture;
    private Texture2D _esqueletoSpriteSheetTexture;

    //regiones
    private TextureRegion _regionErizoFrente;
    private TextureRegion principe1frente;
    private TextureRegion principe2frente;

    //animaciones
    private Dictionary<string, Animation> _animacionesHeroe1;
    private Dictionary<string, Animation> _animacionesHeroe2;
    private string _estadoAnimacionHeroe1 = "Frente";
    private string _estadoAnimacionHeroe2 = "Frente";

    private Animation _animacionRanaSalto;
    private Vector2 _posicionRana = new Vector2(400, 300);
    private float _tiempoSaltoRana = 0f;
    //botones
    private Texture2D _botonesTexture;
    private TextureRegion _regionBotonIniciar;
    private TextureRegion _regionBoton1Jugador;
    private TextureRegion _regionBoton2Jugadores;



    private int _numeroJugadores = 1;
    private int _opcionSeleccionada = 0;
    private KeyboardState _tecladoAnterior;


    //donde aparecen los jugadores
    private Vector2 _posicionHeroe1;
    private Vector2 _posicionHeroe2;
    private Vector2 _posicionErizo;
    private Rectangle rectanguloHeroe1;
    private Rectangle rectanguloHeroe2;
    private Vector2 direccionErizo = new Vector2(1, 0);
    private float velocidadErizo = 1.5f;
    private float velocidad = 2.0f;

    float tiempoTranscurrido = 0f;
    bool mostrarEnemigo = false;

    //boton para iniciar
    private Rectangle _botonIniciarRect = new Rectangle(250, 420, 300, 60);

    // seleccionar jugadores
    private Rectangle _boton1JugadorRect = new Rectangle(250, 220, 300, 60);
    private Rectangle _boton2JugadoresRect = new Rectangle(250, 310, 300, 60);

    // Textura de 1x1 píxel para pintar formas y botones sólidos

    public Game1() : base("The ancien's wizard dungeon", 800, 600, false)
    {

    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        base.Initialize();
    }



    protected override void LoadContent()
    {
        // Ejemplo de carga apuntando a la ruta relativa dentro de Content
        //TextureAtlas atlas = TextureAtlas.FromFile(Content, "images/atlas-definition.xml");

        // Y luego extraes tus sprites individuales usando los nombres del XML
        //var jugadorSprite = atlas.CreateSprite("jugador_idle");
        // TODO: use this.Content to load your game content here

        base.LoadContent();

        //cargamos las texturas del content
        pantallaInicial = Content.Load<Texture2D>("PantallaInicial");
        principe1_spritesheetTexture = Content.Load<Texture2D>("principe1_spritesheet");
        principe2_spritesheetTexture = Content.Load<Texture2D>("principe2_spritesheet");
        _ErizoSpriteSheetTexture = Content.Load<Texture2D>("ErizoSpriteSheet");
        _botonesTexture = Content.Load<Texture2D>("botones");
        _ranaSpriteSheetTexture = Content.Load<Texture2D>("ranaSpriteSheet");
        _esqueletoSpriteSheetTexture = Content.Load<Texture2D>("esqueletoSpriteSheet");

        // definimos regiones (TextureRegion toma: Texture, X, Y, Ancho, Alto)
        int anchoBoton = 57;
        int altoBoton = 11;
        int anchoerizo = 34;
        int altoerizo = 32;


        _regionBotonIniciar = new TextureRegion(_botonesTexture, 0, 0, anchoBoton, altoBoton);
        _regionBoton1Jugador = new TextureRegion(_botonesTexture, 0, 13, anchoBoton, altoBoton);
        _regionBoton2Jugadores = new TextureRegion(_botonesTexture, 0, 26, anchoBoton, altoBoton);
        _regionErizoFrente = new TextureRegion(_ErizoSpriteSheetTexture, 34, 35, anchoerizo, altoerizo);
        principe1frente = new TextureRegion(principe1_spritesheetTexture, 31, 0, 22, 27);
        principe2frente = new TextureRegion(principe2_spritesheetTexture, 31, 0, 22, 27);

        TextureAtlas atlasP1 = new TextureAtlas(principe1_spritesheetTexture);
        atlasP1.AddRegion("frente", 32, 0, 20, 25);
        atlasP1.AddRegion("frente_0", 0, 0, 20, 25);
        atlasP1.AddRegion("frente_1", 64, 0, 83, 25);
        atlasP1.AddRegion("der", 32, 33, 13, 26);
        atlasP1.AddRegion("der_0", 0, 32, 20, 28);
        atlasP1.AddRegion("der_1", 64, 32, 20, 28);
        atlasP1.AddRegion("izq", 32, 65, 13, 26);
        atlasP1.AddRegion("izq_0", 0, 64, 20, 28);
        atlasP1.AddRegion("izq_1", 64, 64, 20, 28);
        atlasP1.AddRegion("atras", 32, 96, 20, 25);
        atlasP1.AddRegion("atras_0", 0, 96, 20, 25);
        atlasP1.AddRegion("atras_1", 64, 96, 20, 25);

        _animacionesHeroe1 = new Dictionary<string, Animation>
        {
            { "Frente", new Animation(new List<TextureRegion> { atlasP1.GetRegion("frente_0"),atlasP1.GetRegion("frente"), atlasP1.GetRegion("frente_1"),atlasP1.GetRegion("frente") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Izquierda", new Animation(new List<TextureRegion> { atlasP1.GetRegion("izq_0"),atlasP1.GetRegion("izq"), atlasP1.GetRegion("izq_1"),atlasP1.GetRegion("izq") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Derecha", new Animation(new List<TextureRegion> { atlasP1.GetRegion("der_0"),atlasP1.GetRegion("der"), atlasP1.GetRegion("der_1"),atlasP1.GetRegion("der") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Atras", new Animation(new List<TextureRegion> { atlasP1.GetRegion("atras_0"),atlasP1.GetRegion("atras"), atlasP1.GetRegion("atras_1"),atlasP1.GetRegion("atras") }, System.TimeSpan.FromMilliseconds(200)) }
        };

        TextureAtlas atlasP2 = new TextureAtlas(principe2_spritesheetTexture);
 atlasP2.AddRegion("frente", 32, 0, 20, 25);
        atlasP2.AddRegion("frente_0", 0, 0, 20, 25);
        atlasP2.AddRegion("frente_1", 64, 0, 83, 25);
        atlasP2.AddRegion("der", 32, 33, 13, 26);
        atlasP2.AddRegion("der_0", 0, 32, 20, 28);
        atlasP2.AddRegion("der_1", 64, 32, 20, 28);
        atlasP2.AddRegion("izq", 32, 65, 13, 26);
        atlasP2.AddRegion("izq_0", 0, 64, 20, 28);
        atlasP2.AddRegion("izq_1", 64, 64, 20, 28);
        atlasP2.AddRegion("atras", 32, 96, 20, 25);
        atlasP2.AddRegion("atras_0", 0, 96, 20, 25);
        atlasP2.AddRegion("atras_1", 64, 96, 20, 25);
        _animacionesHeroe2 = new Dictionary<string, Animation>
        {
          { "Frente", new Animation(new List<TextureRegion> { atlasP2.GetRegion("frente_0"),atlasP2.GetRegion("frente"), atlasP2.GetRegion("frente_1"),atlasP2.GetRegion("frente") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Izquierda", new Animation(new List<TextureRegion> { atlasP2.GetRegion("izq_0"),atlasP2.GetRegion("izq"), atlasP2.GetRegion("izq_1"),atlasP2.GetRegion("izq") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Derecha", new Animation(new List<TextureRegion> { atlasP2.GetRegion("der_0"),atlasP2.GetRegion("der"), atlasP2.GetRegion("der_1"),atlasP2.GetRegion("der") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Atras", new Animation(new List<TextureRegion> { atlasP2.GetRegion("atras_0"),atlasP2.GetRegion("atras"), atlasP2.GetRegion("atras_1"),atlasP2.GetRegion("atras") }, System.TimeSpan.FromMilliseconds(200)) }
        };

        TextureAtlas atlasRana = new TextureAtlas(_ranaSpriteSheetTexture);
        atlasRana.AddRegion("base", 0, 0, 16, 16);
        atlasRana.AddRegion("salto", 16, 0, 16, 16);
         atlasRana.AddRegion("aterriza_0", 0, 16, 16, 16);
          atlasRana.AddRegion("aterriza_1", 16, 16, 16, 16);
        _animacionRanaSalto = new Animation(new List<TextureRegion> { atlasRana.GetRegion("base"), atlasRana.GetRegion("salto"), atlasRana.GetRegion("aterriza_0"),atlasRana.GetRegion("aterriza_1") }, System.TimeSpan.FromMilliseconds(500));



        int anchoBotonEscalado = 57 * 4;
        int altoBotonEscalado = 11 * 4;
        int posXCentrada = (Window.ClientBounds.Width - anchoBotonEscalado) / 2;

        _botonIniciarRect = new Rectangle(posXCentrada, 420, anchoBotonEscalado, altoBotonEscalado);
        _boton1JugadorRect = new Rectangle(posXCentrada, 220, anchoBotonEscalado, altoBotonEscalado);
        _boton2JugadoresRect = new Rectangle(posXCentrada, 310, anchoBotonEscalado, altoBotonEscalado);

        //cargamos todos los mapas xml
        _tileMap = Tilemap.FromFile(Content, "Levels/Level1.xml");

        // posicion heroes
        _posicionHeroe1 = new Vector2(100, 100);
        _posicionHeroe2 = new Vector2(140, 100);
        rectanguloHeroe1 = new Rectangle(100, 100, principe1frente.Width, principe1frente.Height);
        rectanguloHeroe2 = new Rectangle(140, 100, principe2frente.Width, principe2frente.Height);
        _posicionErizo = new Vector2(600, 200);

        // escalamos el mapa para que sea mas grande ya que sino tienen que ser muchas baldosas
        _tileMap.Scale = new Vector2(2f, 2f);



    }

    protected override void Update(GameTime gameTime)
    {


        tiempoTranscurrido +=
        (float)gameTime.ElapsedGameTime.TotalSeconds;


        var tecladoActual = Keyboard.GetState();

        if (tecladoActual.IsKeyDown(Keys.Escape))
        {
            Exit();
        }
        switch (_estadoActual)
        {

            case EstadoJuego.MenuPrincipal:

                if ((tecladoActual.IsKeyDown(Keys.Enter) && _tecladoAnterior.IsKeyUp(Keys.Enter)) ||
                     (tecladoActual.IsKeyDown(Keys.Space) && _tecladoAnterior.IsKeyUp(Keys.Space)))
                {
                    _estadoActual = EstadoJuego.SeleccionJugadores;
                    _tecladoAnterior = tecladoActual;
                }
                break;

            case EstadoJuego.SeleccionJugadores:
                //  1 Jugador
                if ((tecladoActual.IsKeyDown(Keys.Up) && _tecladoAnterior.IsKeyUp(Keys.Up)) ||
                     (tecladoActual.IsKeyDown(Keys.W) && _tecladoAnterior.IsKeyUp(Keys.W)))
                {
                    _numeroJugadores = 1;
                    _opcionSeleccionada = 0;
                    _tecladoAnterior = tecladoActual;

                }
                /* Circle posicionerizoBounds = new Circle(
            (int)(_ErizoSpriteSheetPosition.X + (_slime.Width * 0.5f)),
            (int)(_slimePosition.Y + (_slime.Heiaaaaaaa ght * 0.5f)),
            (int)(_slime.Width * 0.5f)
        );*/

                //  2 Jugadores
                if ((tecladoActual.IsKeyDown(Keys.Down) && _tecladoAnterior.IsKeyUp(Keys.Down)) ||
                     (tecladoActual.IsKeyDown(Keys.S) && _tecladoAnterior.IsKeyUp(Keys.S)))
                {
                    _numeroJugadores = 2;
                    _opcionSeleccionada = 1;
                    _tecladoAnterior = tecladoActual;
                }
                if ((tecladoActual.IsKeyDown(Keys.Enter) && _tecladoAnterior.IsKeyUp(Keys.Enter)) ||
             (tecladoActual.IsKeyDown(Keys.Space) && _tecladoAnterior.IsKeyUp(Keys.Space)))
                {
                    _estadoActual = EstadoJuego.Jugando;
                }


                break;

            case EstadoJuego.Jugando:

                //ACA VA A IR LA LOGICA CUANDO ESTES JUGANDO
                bool moviendoH1 = false;
                if (tecladoActual.IsKeyDown(Keys.A))
                {
                    _posicionHeroe1.X -= velocidad;
                    _estadoAnimacionHeroe1 = "Izquierda";
                    moviendoH1 = true;
                }
                else if (tecladoActual.IsKeyDown(Keys.D))
                {
                    _posicionHeroe1.X += velocidad;
                    _estadoAnimacionHeroe1 = "Derecha";
                    moviendoH1 = true;
                }

                if (tecladoActual.IsKeyDown(Keys.S))
                {
                    _posicionHeroe1.Y += velocidad;
                    if (!moviendoH1) _estadoAnimacionHeroe1 = "Frente";
                    moviendoH1 = true;
                }
                else if (tecladoActual.IsKeyDown(Keys.W))
                {
                    _posicionHeroe1.Y -= velocidad;
                    if (!moviendoH1) _estadoAnimacionHeroe1 = "Atras";
                    moviendoH1 = true;
                }

                if (moviendoH1)
                {
                    _animacionesHeroe1[_estadoAnimacionHeroe1].Update(gameTime);
                }
                else
                {
                    _animacionesHeroe1["Frente"].Reset();
                }
                //mov heroe 2
                bool moviendoH2 = false;
                if (tecladoActual.IsKeyDown(Keys.Left))
                {
                    _posicionHeroe2.X -= velocidad;
                    _estadoAnimacionHeroe2 = "Izquierda";
                    moviendoH2 = true;
                }
                else if (tecladoActual.IsKeyDown(Keys.Right))
                {
                    _posicionHeroe2.X += velocidad;
                    _estadoAnimacionHeroe2 = "Derecha";
                    moviendoH2 = true;
                }

                if (tecladoActual.IsKeyDown(Keys.Down))
                {
                    _posicionHeroe2.Y += velocidad;
                    if (!moviendoH2) _estadoAnimacionHeroe2 = "Frente";
                    moviendoH2 = true;
                }
                else if (tecladoActual.IsKeyDown(Keys.Up))
                {
                    _posicionHeroe2.Y -= velocidad;
                    if (!moviendoH2) _estadoAnimacionHeroe2 = "Atras";
                    moviendoH2 = true;
                }

                if (moviendoH2)
                {
                    _animacionesHeroe2[_estadoAnimacionHeroe2].Update(gameTime);
                }
                else
                {
                    _animacionesHeroe2["Frente"].Reset();
                }

                // actualizar la animación de la rana 
                _animacionRanaSalto.Update(gameTime);
                _tiempoSaltoRana += (float)gameTime.ElapsedGameTime.TotalSeconds;

                rectanguloHeroe1.X = (int)_posicionHeroe1.X;
                rectanguloHeroe1.Y = (int)_posicionHeroe1.Y;

                rectanguloHeroe2.X = (int)_posicionHeroe2.X;
                rectanguloHeroe2.Y = (int)_posicionHeroe2.Y;

                if (!limitesMapa.Contains(rectanguloHeroe1))
                {
                    _posicionHeroe1.X = MathHelper.Clamp(_posicionHeroe1.X, 0, limitesMapa.Width - rectanguloHeroe1.Width);
                    _posicionHeroe1.Y = MathHelper.Clamp(_posicionHeroe1.Y, 0, limitesMapa.Height - rectanguloHeroe1.Height);
                }

                if (!limitesMapa.Contains(rectanguloHeroe2))
                {
                    _posicionHeroe2.X = MathHelper.Clamp(_posicionHeroe2.X, 0, limitesMapa.Width - rectanguloHeroe2.Width);
                    _posicionHeroe2.Y = MathHelper.Clamp(_posicionHeroe2.Y, 0, limitesMapa.Height - rectanguloHeroe2.Height);
                }

                mostrarEnemigo = false;
                if (tiempoTranscurrido >= 5f)
                {
                    mostrarEnemigo = true;
                }

                if (mostrarEnemigo)
                {
                    _posicionErizo += direccionErizo * velocidadErizo;

                    if (_posicionErizo.X >= 750) direccionErizo.X = -1;
                    if (_posicionErizo.X <= 50) direccionErizo.X = 1;
                    if (_posicionErizo.Y >= 550) direccionErizo.Y = -1;
                    if (_posicionErizo.Y <= 50) direccionErizo.Y = 1;
                }
                break;
        }
        // TODO: Add your update logic here


        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);


        // Begin the sprite batch to prepare for rendering.
        SpriteBatch.Begin(samplerState: SamplerState.PointWrap);

        if (_estadoActual == EstadoJuego.MenuPrincipal)
        {


            //tamaño de la pantalla inicial escalado a la pantalla del juego
            float escalaXTitulo = (float)Window.ClientBounds.Width / pantallaInicial.Width;
            float escalaYTitulo = (float)Window.ClientBounds.Height / pantallaInicial.Height;
            SpriteBatch.Draw(
                            pantallaInicial,
                            Vector2.Zero,
                            null,
                            Color.White,
                            0,
                            Vector2.Zero,
                            new Vector2(escalaXTitulo, escalaYTitulo),
                            SpriteEffects.None,
                            0.0f
                        );


            _regionBotonIniciar.Draw(
                SpriteBatch,
                new Vector2(_botonIniciarRect.X, _botonIniciarRect.Y),
                Color.Gold,
                0f,
                Vector2.Zero,
                new Vector2(4f, 4f),
                SpriteEffects.None,
                0f
            );
        }

        else if (_estadoActual == EstadoJuego.SeleccionJugadores)
        {

            GraphicsDevice.Clear(Color.DarkSlateGray);

            // El botón activo se pinta de Gold, el inactivo de White
            Color colorBoton1 = (_opcionSeleccionada == 0) ? Color.Gold : Color.White;
            Color colorBoton2 = (_opcionSeleccionada == 1) ? Color.Gold : Color.White;

            _regionBoton1Jugador.Draw(
                SpriteBatch,
                new Vector2(_boton1JugadorRect.X, _boton1JugadorRect.Y),
                colorBoton1,
                0f,
                Vector2.Zero,
                new Vector2(4f, 4f),
                SpriteEffects.None,
                0f
            );

            _regionBoton2Jugadores.Draw(
                SpriteBatch,
                new Vector2(_boton2JugadoresRect.X, _boton2JugadoresRect.Y),
                colorBoton2,
                0f,
                Vector2.Zero,
                new Vector2(4f, 4f),
                SpriteEffects.None,
                0f
            );

        }
        else if (_estadoActual == EstadoJuego.Jugando)
        {
            _tileMap.Draw(SpriteBatch);
            TextureRegion frameHeroe1 = _animacionesHeroe1[_estadoAnimacionHeroe1].CurrentFrame;
            frameHeroe1.Draw(
                SpriteBatch,
                new Vector2(_posicionHeroe1.X, _posicionHeroe1.Y),
                Color.White,
                0f,
                Vector2.Zero,
                new Vector2(3f, 3f),
                SpriteEffects.None,
                0f);

            if (_numeroJugadores == 2)
            {
                
                TextureRegion frameHeroe2 = _animacionesHeroe2[_estadoAnimacionHeroe2].CurrentFrame;
                frameHeroe2.Draw(
                   SpriteBatch,
                   new Vector2(_posicionHeroe2.X, _posicionHeroe2.Y),
                   Color.White,
                   0f,
                   Vector2.Zero,
                   new Vector2(3f, 3f),
                   SpriteEffects.None,
                   0f);
            }

            if (mostrarEnemigo == true)
            {
                _regionErizoFrente.Draw(
                    SpriteBatch,
                    new Vector2(_posicionErizo.X, _posicionErizo.Y),
                    Color.White,
                    0f,
                    Vector2.Zero,
                    new Vector2(2f, 2f),
                    SpriteEffects.None,
                    0f);

                
                TextureRegion frameRana = _animacionRanaSalto.CurrentFrame;
                frameRana.Draw(
                    SpriteBatch,
                    _posicionRana,
                    Color.White,
                    0f,
                    Vector2.Zero,
                    new Vector2(2f, 2f),
                    SpriteEffects.None,
                    0f);
            }
        }




        // Always end the sprite batch when finished.
        SpriteBatch.End();

        base.Draw(gameTime);
    }
}
