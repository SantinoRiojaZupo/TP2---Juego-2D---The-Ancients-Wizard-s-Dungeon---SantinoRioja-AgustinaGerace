//using System.Numerics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGameLibrary;
using MonoGameLibrary.Graphics;
using System.Collections.Generic;
using MonoGameLibrary.Physics;
//using System.Numerics;

namespace The_ancient_s_wizard_dungeon;
//cd '.\Juego\The ancient''s wizard dungeon\'
//despues
//dotnet mgcb-editor ./Content/Content.mgcb

public class Game1 : Core
{

    //estados del juego
    private enum EstadoJuego
    {
        MenuPrincipal,
        SeleccionJugadores,
        Jugando,
        Pausado,
        Opciones,
        Victoria,
        Derrota
    }
    private EstadoJuego _estadoAnteriorOpciones;
    private Tilemap _tileMap;
    private UIManager _uiManager;
    private Rectangle limitesMapa = new Rectangle(15, 0, 770, 590);

    private EstadoJuego _estadoActual = EstadoJuego.MenuPrincipal;
    private Texture2D pantallaInicial;
    private Texture2D principe1_spritesheetTexture;
    private Texture2D principe2_spritesheetTexture;
    private Texture2D _ErizoSpriteSheetTexture;
    private Texture2D _ranaSpriteSheetTexture;
    private Texture2D _esqueletoSpriteSheetTexture;
    private Texture2D _texturaElementos;

    //regiones
    private TextureRegion _regionErizoFrente;
    private TextureRegion principe1frente;
    private TextureRegion principe2frente;

    //animaciones
    private Dictionary<string, Animation> _animacionesHeroe1;
    private Dictionary<string, Animation> _animacionesHeroe2;
    private string _estadoAnimacionHeroe1 = "Frente";
    private string _estadoAnimacionHeroe2 = "Frente";

    private Animation _animacionRanaSalto;
    private Animation _animacionRanaAterriza;
    private Vector2 inicioSaltoRana;
    private Vector2 _posicionRana = new Vector2(400, 300);
    private float _tiempoSaltoRana = 1.5f;
    //botones
private Texture2D _botonesTexture;

private TextureRegion _regionBotonIniciar;
private TextureRegion _regionBoton1Jugador;
private TextureRegion _regionBoton2Jugadores;
private TextureRegion _regionBotonSalir;
private TextureRegion _regionBotonOpciones;
private TextureRegion _regionBotonVacio;


    

    private int _numeroJugadores = 1;
    private KeyboardState _tecladoAnterior;


    //donde aparecen los jugadores
    private Jugador _jugador1;
    private Jugador _jugador2;
    
    private Vector2 _posicionHeroe1;
    private Vector2 _posicionHeroe2;
    private Vector2 _posicionErizo;
    private Rectangle rectanguloHeroe1;
    private Rectangle rectanguloHeroe2;
    private Rectangle rectanguloErizo;
    private CollisionBody _cuerpoHeroe1;
    private CollisionBody _cuerpoHeroe2;
    private CollisionBody _cuerpoErizo;
    private CollisionBody _cuerpoRana;
    private Vector2 direccionErizo = new Vector2(1, 0);
    private float velocidadErizo = 1.5f;

    private float velocidad = 2.0f;
    //private float tiempoErizo = 0f;
    //bool erizoMoviendose = false;
    private float tiempoMovimientoRana = 0f;
    private float intervaloMovimientoRana = 0.7f;
    private bool erizoEnPausa = false;
    private bool tocandoErizoHeroe1 = false;
    private bool tocandoErizoHeroe2 = false;
    private bool tocandoRanaHeroe1 = false;
    private bool tocandoRanaHeroe2 = false;
    private float tiempoPausaErizo = 0f;
    private float tiempoRetrocesoErizo = 0f;
    private bool ranaSaltando = false;
    private Vector2 destinoRana;
    private float tiempoAnimacionRana = 0f;
    private float duracionSaltoRana = 2f;
    private Vector2 direccionRetrocesoErizo;

    private float velocidadRetrocesoErizo = 2f;
    float tiempoTranscurrido = 0f;
    bool mostrarEnemigo = false;

    //boton para iniciar
    private Rectangle _botonIniciarRect = new Rectangle(250, 420, 300, 60);

    // seleccionar jugadores
    private Rectangle _boton1JugadorRect = new Rectangle(250, 220, 300, 60);
    private Rectangle _boton2JugadoresRect = new Rectangle(250, 310, 300, 60);

    // Textura de 1x1 píxel para pintar formas y botones sólidos

    public Game1() : base("The ancien's wizard dungeon", 800, 600, false)
    {

    }

    protected override void Initialize()
    {
        // TODO: Add your initialization logic here

        base.Initialize();
    }



    protected override void LoadContent()
    {
        // Ejemplo de carga apuntando a la ruta relativa dentro de Content
        //TextureAtlas atlas = TextureAtlas.FromFile(Content, "images/atlas-definition.xml");

        // Y luego extraes tus sprites individuales usando los nombres del XML
        //var jugadorSprite = atlas.CreateSprite("jugador_idle");
        // TODO: use this.Content to load your game content here

        base.LoadContent();

        //cargamos las texturas del content
        pantallaInicial = Content.Load<Texture2D>("PantallaInicial");
        principe1_spritesheetTexture = Content.Load<Texture2D>("principe1_spritesheet");
        principe2_spritesheetTexture = Content.Load<Texture2D>("principe2_spritesheet");
        _ErizoSpriteSheetTexture = Content.Load<Texture2D>("ErizoSpriteSheet");
        _botonesTexture = Content.Load<Texture2D>("botones");
        _ranaSpriteSheetTexture = Content.Load<Texture2D>("ranaSpriteSheet");
        _esqueletoSpriteSheetTexture = Content.Load<Texture2D>("esqueletoSpriteSheet");
        _texturaElementos = Content.Load<Texture2D>("ElementosSpriteSheet");


        // definimos regiones (TextureRegion toma: Texture, X, Y, Ancho, Alto)
        int anchoBoton = 57;
        int altoBoton = 11;
        int anchoerizo = 34;
        int altoerizo = 32;


       _regionBotonIniciar = new TextureRegion(
    _botonesTexture, 0, 0, anchoBoton, altoBoton);

_regionBoton1Jugador = new TextureRegion(
    _botonesTexture, 0, 13, anchoBoton, altoBoton);

_regionBoton2Jugadores = new TextureRegion(
    _botonesTexture, 0, 26, anchoBoton, altoBoton);

_regionBotonSalir = new TextureRegion(
    _botonesTexture, 0, 39, anchoBoton, altoBoton);

_regionBotonOpciones = new TextureRegion(
    _botonesTexture, 0, 52, anchoBoton, altoBoton);

_regionBotonVacio = new TextureRegion(
    _botonesTexture, 0, 65, anchoBoton, altoBoton);

        // UIManager controla la navegación y el dibujo de los menús.
        _uiManager = new UIManager(
            _regionBotonIniciar,
            _regionBoton1Jugador,
              _regionBoton2Jugadores,
    _regionBotonSalir,
    _regionBotonOpciones,
    _regionBotonVacio
        );
        _regionErizoFrente = new TextureRegion(_ErizoSpriteSheetTexture, 34, 35, anchoerizo, altoerizo);
        principe1frente = new TextureRegion(principe1_spritesheetTexture, 31, 0, 22, 27);
        principe2frente = new TextureRegion(principe2_spritesheetTexture, 31, 0, 22, 27);

        TextureAtlas atlasP1 = new TextureAtlas(principe1_spritesheetTexture);
        atlasP1.AddRegion("frente", 32, 0, 20, 25);
        atlasP1.AddRegion("frente_0", 0, 0, 20, 25);
        atlasP1.AddRegion("frente_1", 64, 0, 20, 25);
        atlasP1.AddRegion("der", 32, 33, 13, 26);
        atlasP1.AddRegion("der_0", 0, 32, 20, 28);
        atlasP1.AddRegion("der_1", 64, 32, 20, 28);
        atlasP1.AddRegion("izq", 32, 65, 13, 26);
        atlasP1.AddRegion("izq_0", 0, 64, 20, 28);
        atlasP1.AddRegion("izq_1", 64, 64, 20, 28);
        atlasP1.AddRegion("atras", 32, 96, 20, 25);
        atlasP1.AddRegion("atras_0", 0, 96, 20, 25);
        atlasP1.AddRegion("atras_1", 64, 96, 20, 25);

        _animacionesHeroe1 = new Dictionary<string, Animation>
        {
            { "Frente", new Animation(new List<TextureRegion> { atlasP1.GetRegion("frente_0"),atlasP1.GetRegion("frente"), atlasP1.GetRegion("frente_1"),atlasP1.GetRegion("frente") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Izquierda", new Animation(new List<TextureRegion> { atlasP1.GetRegion("izq_0"),atlasP1.GetRegion("izq"), atlasP1.GetRegion("izq_1"),atlasP1.GetRegion("izq") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Derecha", new Animation(new List<TextureRegion> { atlasP1.GetRegion("der_0"),atlasP1.GetRegion("der"), atlasP1.GetRegion("der_1"),atlasP1.GetRegion("der") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Atras", new Animation(new List<TextureRegion> { atlasP1.GetRegion("atras_0"),atlasP1.GetRegion("atras"), atlasP1.GetRegion("atras_1"),atlasP1.GetRegion("atras") }, System.TimeSpan.FromMilliseconds(200)) },
            { "quietoFrente", new Animation(new List<TextureRegion> { atlasP1.GetRegion("frente") }, System.TimeSpan.FromMilliseconds(200)) },
             { "quietoIzquierda", new Animation(new List<TextureRegion> { atlasP1.GetRegion("izq") }, System.TimeSpan.FromMilliseconds(200)) },
              { "quietoDerecha", new Animation(new List<TextureRegion> { atlasP1.GetRegion("der") }, System.TimeSpan.FromMilliseconds(200)) },
               { "quietoAtras", new Animation(new List<TextureRegion> { atlasP1.GetRegion("atras") }, System.TimeSpan.FromMilliseconds(200)) }

        };

        TextureAtlas atlasP2 = new TextureAtlas(principe2_spritesheetTexture);
        atlasP2.AddRegion("frente", 32, 0, 20, 25);
        atlasP2.AddRegion("frente_0", 0, 0, 20, 25);
        atlasP2.AddRegion("frente_1", 64, 0, 20, 25);
        atlasP2.AddRegion("der", 32, 33, 13, 26);
        atlasP2.AddRegion("der_0", 0, 32, 20, 28);
        atlasP2.AddRegion("der_1", 64, 32, 20, 28);
        atlasP2.AddRegion("izq", 32, 65, 13, 26);
        atlasP2.AddRegion("izq_0", 0, 64, 20, 28);
        atlasP2.AddRegion("izq_1", 64, 64, 20, 28);
        atlasP2.AddRegion("atras", 32, 96, 20, 25);
        atlasP2.AddRegion("atras_0", 0, 96, 20, 25);
        atlasP2.AddRegion("atras_1", 64, 96, 20, 25);
        _animacionesHeroe2 = new Dictionary<string, Animation>
        {
          { "Frente", new Animation(new List<TextureRegion> { atlasP2.GetRegion("frente_0"),atlasP2.GetRegion("frente"), atlasP2.GetRegion("frente_1"),atlasP2.GetRegion("frente") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Izquierda", new Animation(new List<TextureRegion> { atlasP2.GetRegion("izq_0"),atlasP2.GetRegion("izq"), atlasP2.GetRegion("izq_1"),atlasP2.GetRegion("izq") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Derecha", new Animation(new List<TextureRegion> { atlasP2.GetRegion("der_0"),atlasP2.GetRegion("der"), atlasP2.GetRegion("der_1"),atlasP2.GetRegion("der") }, System.TimeSpan.FromMilliseconds(200)) },
            { "Atras", new Animation(new List<TextureRegion> { atlasP2.GetRegion("atras_0"),atlasP2.GetRegion("atras"), atlasP2.GetRegion("atras_1"),atlasP2.GetRegion("atras") }, System.TimeSpan.FromMilliseconds(200)) },
            { "quietoFrente", new Animation(new List<TextureRegion> { atlasP2.GetRegion("frente") }, System.TimeSpan.FromMilliseconds(200)) },
             { "quietoIzquierda", new Animation(new List<TextureRegion> { atlasP2.GetRegion("izq") }, System.TimeSpan.FromMilliseconds(200)) },
              { "quietoDerecha", new Animation(new List<TextureRegion> { atlasP2.GetRegion("der") }, System.TimeSpan.FromMilliseconds(200)) },
               { "quietoAtras", new Animation(new List<TextureRegion> { atlasP2.GetRegion("atras") }, System.TimeSpan.FromMilliseconds(200)) }
        };

        TextureAtlas atlasRana = new TextureAtlas(_ranaSpriteSheetTexture);
        atlasRana.AddRegion("base", 0, 0, 16, 16);
        atlasRana.AddRegion("salto", 16, 0, 16, 16);
        atlasRana.AddRegion("aterriza_0", 0, 16, 16, 16);
        atlasRana.AddRegion("aterriza_1", 16, 16, 16, 16);
        _animacionRanaSalto = new Animation(new List<TextureRegion> { atlasRana.GetRegion("base"), atlasRana.GetRegion("salto") }, System.TimeSpan.FromMilliseconds(500));
        _animacionRanaAterriza = new Animation(new List<TextureRegion> { atlasRana.GetRegion("aterriza_0"), atlasRana.GetRegion("aterriza_1"), atlasRana.GetRegion("aterriza_0"), atlasRana.GetRegion("aterriza_1") }, System.TimeSpan.FromMilliseconds(500));





        //cargamos todos los mapas xml
        _tileMap = Tilemap.FromFile(Content, "Levels/Level1.xml");

        // posicion heroes
        _posicionHeroe1 = new Vector2(100, 100);
        _posicionHeroe2 = new Vector2(180, 100);
        rectanguloHeroe1 = new Rectangle(100, 100, principe1frente.Width, principe1frente.Height);
        rectanguloHeroe2 = new Rectangle(180, 100, principe2frente.Width, principe2frente.Height);
        _posicionErizo = new Vector2(600, 200);

        _cuerpoHeroe1 = new CollisionBody(
          _animacionesHeroe1.Values,
         _posicionHeroe1
         );

        _cuerpoHeroe2 = new CollisionBody(
        _animacionesHeroe2.Values,
        _posicionHeroe2
    );

        _cuerpoErizo = new CollisionBody(
           new Point(_regionErizoFrente.Width * 2, _regionErizoFrente.Height * 2),
            _posicionErizo
        );
        _cuerpoRana = new CollisionBody(
         new Point(24, 24),
        _posicionRana
        );


        // escalamos el mapa para que sea mas grande ya que sino tienen que ser muchas baldosas
        _tileMap.Scale = new Vector2(2f, 2f);

        _jugador1 = new Jugador (_texturaElementos, _posicionHeroe1);
        _jugador2 = new Jugador (_texturaElementos, _posicionHeroe2);



    }

    protected override void Update(GameTime gameTime)
    {



  


        var tecladoActual = Keyboard.GetState();

       if (tecladoActual.IsKeyDown(Keys.Escape) &&
    _tecladoAnterior.IsKeyUp(Keys.Escape))
{
    if (_estadoActual == EstadoJuego.Jugando)
    {
        _estadoActual = EstadoJuego.Pausado;
        _uiManager.ReiniciarSeleccion();
    }
    else if (_estadoActual == EstadoJuego.Pausado)
    {
        _estadoActual = EstadoJuego.Jugando;
    }
}
        switch (_estadoActual)
        {

            case EstadoJuego.MenuPrincipal:

 _uiManager.Update(gameTime, 3);

if (_uiManager.Confirmar)
{
    switch (_uiManager.SelectedIndex)
    {
        case 0:
            // JUGAR
            _estadoActual = EstadoJuego.SeleccionJugadores;
            _uiManager.ReiniciarSeleccion();
            break;

        case 1:
            // OPCIONES
            _estadoAnteriorOpciones = EstadoJuego.MenuPrincipal;
            _estadoActual = EstadoJuego.Opciones;
            _uiManager.ReiniciarSeleccion();
            break;

        case 2:
            // SALIR
            Exit();
            break;
    }
}
    break;

            case EstadoJuego.SeleccionJugadores:

                _uiManager.Update(gameTime, 2);

                if (_uiManager.Confirmar)
                {
                    _numeroJugadores = _uiManager.SelectedIndex + 1;
                    _estadoActual = EstadoJuego.Jugando;
                }

                break;

            case EstadoJuego.Jugando:

                  tiempoTranscurrido +=
        (float)gameTime.ElapsedGameTime.TotalSeconds;

                //ACA VA A IR LA LOGICA CUANDO ESTES JUGANDO
                Vector2 posicionAnteriorErizo = _posicionErizo;
                Vector2 movimientoH1 = Vector2.Zero;
                Vector2 movimientoH2 = Vector2.Zero;
                bool moviendoH1 = false;
                if (tecladoActual.IsKeyDown(Keys.Left))
                {
                    movimientoH1.X -= velocidad;
                    _estadoAnimacionHeroe1 = "Izquierda";
                    moviendoH1 = true;
                }
                else if (tecladoActual.IsKeyDown(Keys.Right))
                {
                    movimientoH1.X += velocidad;
                    _estadoAnimacionHeroe1 = "Derecha";
                    moviendoH1 = true;
                }

                if (tecladoActual.IsKeyDown(Keys.Down))
                {
                    movimientoH1.Y += velocidad;
                    if (!moviendoH1) _estadoAnimacionHeroe1 = "Frente";
                    moviendoH1 = true;
                }
                else if (tecladoActual.IsKeyDown(Keys.Up))
                {
                    movimientoH1.Y -= velocidad;
                    if (!moviendoH1) _estadoAnimacionHeroe1 = "Atras";
                    moviendoH1 = true;
                }

                if (moviendoH1)
                {
                    _animacionesHeroe1[_estadoAnimacionHeroe1].Update(gameTime);
                }
                else
                {
                    if (_estadoAnimacionHeroe1 == "Frente")
                    {
                        _estadoAnimacionHeroe1 = "quietoFrente";
                    }
                    else if (_estadoAnimacionHeroe1 == "Atras")
                    {
                        _estadoAnimacionHeroe1 = "quietoAtras";
                    }
                    else if (_estadoAnimacionHeroe1 == "Derecha")
                    {
                        _estadoAnimacionHeroe1 = "quietoDerecha";
                    }
                    else if (_estadoAnimacionHeroe1 == "Izquierda")
                    {
                        _estadoAnimacionHeroe1 = "quietoIzquierda";
                    }

                }
                //mov heroe 2
                bool moviendoH2 = false;
                if (tecladoActual.IsKeyDown(Keys.A))
                {
                    movimientoH2.X -= velocidad;
                    _estadoAnimacionHeroe2 = "Izquierda";
                    moviendoH2 = true;
                }
                else if (tecladoActual.IsKeyDown(Keys.D))
                {
                    movimientoH2.X += velocidad;
                    _estadoAnimacionHeroe2 = "Derecha";
                    moviendoH2 = true;
                }

                if (tecladoActual.IsKeyDown(Keys.S))
                {
                    movimientoH2.Y += velocidad;
                    if (!moviendoH2) _estadoAnimacionHeroe2 = "Frente";
                    moviendoH2 = true;
                }
                else if (tecladoActual.IsKeyDown(Keys.W))
                {
                    movimientoH2.Y -= velocidad;
                    if (!moviendoH2) _estadoAnimacionHeroe2 = "Atras";
                    moviendoH2 = true;
                }

                if (moviendoH2)
                {
                    _animacionesHeroe2[_estadoAnimacionHeroe2].Update(gameTime);

                }
                else
                {
                    if (_estadoAnimacionHeroe2 == "Frente")
                    {
                        _estadoAnimacionHeroe2 = "quietoFrente";
                    }
                    else if (_estadoAnimacionHeroe2 == "Atras")
                    {
                        _estadoAnimacionHeroe2 = "quietoAtras";
                    }
                    else if (_estadoAnimacionHeroe2 == "Derecha")
                    {
                        _estadoAnimacionHeroe2 = "quietoDerecha";
                    }
                    else if (_estadoAnimacionHeroe2 == "Izquierda")
                    {
                        _estadoAnimacionHeroe2 = "quietoIzquierda";
                    }

                }
                // posicion hitbox
                _cuerpoHeroe1.SetPosition(_posicionHeroe1);
                _cuerpoHeroe2.SetPosition(_posicionHeroe2);
                _cuerpoErizo.SetPosition(_posicionErizo);
                _cuerpoRana.SetPosition(_posicionRana);

                // Movimiento del heroe 1
                if (_numeroJugadores == 2)
                {
                    _cuerpoHeroe1.Move(
                    movimientoH1,
                    _numeroJugadores == 2 ? _cuerpoHeroe2 : null,
                    mostrarEnemigo ? _cuerpoErizo : null,
                    mostrarEnemigo ? _cuerpoRana : null
                    );
                }
                else
                {
                    _cuerpoHeroe1.Move(
                    movimientoH1,
                   _numeroJugadores == 2 ? _cuerpoHeroe2 : null,
                   mostrarEnemigo ? _cuerpoErizo : null,
                   mostrarEnemigo ? _cuerpoRana : null
                  );
                }

                // Movimiento del heroe 2
                if (_numeroJugadores == 2)
                {
                    _cuerpoHeroe2.Move(
               movimientoH2,
               _cuerpoHeroe1,
              mostrarEnemigo ? _cuerpoErizo : null,
               mostrarEnemigo ? _cuerpoRana : null
              );
                }


                _cuerpoHeroe1.KeepInside(limitesMapa);

                if (_numeroJugadores == 2)
                {
                    _cuerpoHeroe2.KeepInside(limitesMapa);
                }


                _posicionHeroe1 = _cuerpoHeroe1.Position;
                _posicionHeroe2 = _cuerpoHeroe2.Position;
                // actualizar la animación de la rana 
                _animacionRanaSalto.Update(gameTime);
                _tiempoSaltoRana += (float)gameTime.ElapsedGameTime.TotalSeconds;

                rectanguloHeroe1.X = (int)_posicionHeroe1.X;
                rectanguloHeroe1.Y = (int)_posicionHeroe1.Y;

                rectanguloHeroe2.X = (int)_posicionHeroe2.X;
                rectanguloHeroe2.Y = (int)_posicionHeroe2.Y;

                if (!limitesMapa.Contains(rectanguloHeroe1))
                {
                    _posicionHeroe1.X = MathHelper.Clamp(_posicionHeroe1.X, 0, limitesMapa.Width - rectanguloHeroe1.Width);
                    _posicionHeroe1.Y = MathHelper.Clamp(_posicionHeroe1.Y, 0, limitesMapa.Height - rectanguloHeroe1.Height);
                }

                if (!limitesMapa.Contains(rectanguloHeroe2))
                {
                    _posicionHeroe2.X = MathHelper.Clamp(_posicionHeroe2.X, 0, limitesMapa.Width - rectanguloHeroe2.Width);
                    _posicionHeroe2.Y = MathHelper.Clamp(_posicionHeroe2.Y, 0, limitesMapa.Height - rectanguloHeroe2.Height);
                }

                mostrarEnemigo = false;
                if (tiempoTranscurrido >= 3f)
                {
                    mostrarEnemigo = true;
                }

                if (mostrarEnemigo)
                {
                    float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

                    _cuerpoHeroe1.SetPosition(_posicionHeroe1);
                    _cuerpoHeroe2.SetPosition(_posicionHeroe2);

                    if (erizoEnPausa)
                    {
                        tiempoPausaErizo -= deltaTime;

                        if (tiempoRetrocesoErizo > 0f)
                        {
                            Vector2 retroceso = direccionRetrocesoErizo
                                       * velocidadRetrocesoErizo
                                       * deltaTime * 60f;

                            if (_numeroJugadores == 2)
                                _cuerpoErizo.Move(retroceso, _cuerpoHeroe1, _cuerpoHeroe2, _cuerpoRana);
                            else
                                _cuerpoErizo.Move(retroceso, _cuerpoHeroe1, _cuerpoRana);

                            tiempoRetrocesoErizo -= deltaTime;
                        }

                        _posicionErizo = _cuerpoErizo.Position;

                        // al termina la pausa vuelve a perseguir
                        if (tiempoPausaErizo <= 0f)
                            erizoEnPausa = false;
                    }
                    else
                    {
                        // busca heroe cercano
                        Vector2 objetivo = _posicionHeroe1;

                        if (_numeroJugadores == 2)
                        {
                            float distanciaH1 = Vector2.Distance(
                                _posicionErizo, _posicionHeroe1);

                            float distanciaH2 = Vector2.Distance(
                                _posicionErizo, _posicionHeroe2);

                            if (distanciaH2 < distanciaH1)
                                objetivo = _posicionHeroe2;
                            else
                            {
                                objetivo = _posicionHeroe1;
                            }
                        }


                        Vector2 direccion = objetivo - _posicionErizo;

                        if (direccion != Vector2.Zero)
                            direccion.Normalize();

                        Vector2 movimiento = direccion * velocidadErizo
                                               * deltaTime * 60f;

                        // verificar q el proximo movimiento no choque
                        Rectangle proximoBounds = new Rectangle(
                         (int)(_cuerpoErizo.Position.X + movimiento.X),
                         (int)(_cuerpoErizo.Position.Y + movimiento.Y),
                         _cuerpoErizo.Bounds.Width,
                         _cuerpoErizo.Bounds.Height
                         );

                        bool chocoH1 = proximoBounds.Intersects(_cuerpoHeroe1.Bounds);
                        bool chocoH2 = _numeroJugadores == 2 &&
                                  proximoBounds.Intersects(_cuerpoHeroe2.Bounds);
                        bool chocoRana = proximoBounds.Intersects(_cuerpoRana.Bounds);
                        if (!chocoH1)
                    tocandoErizoHeroe1 = false;

                        if (!chocoH2)
                      tocandoErizoHeroe2 = false;

                    // Daño al jugador 1
                    if (chocoH1 && !tocandoErizoHeroe1)
                    {
                    _jugador1._vidaJugadores.QuitarVida(1);
                    tocandoErizoHeroe1 = true;
                    }

                        // Daño al jugador 2
                    if (chocoH2 && !tocandoErizoHeroe2)
                    {
                    _jugador2._vidaJugadores.QuitarVida(1);
                    tocandoErizoHeroe2 = true;
                    }

                        if (chocoRana)
                        {
                            float distanciaMovimiento = movimiento.Length();

                            Vector2[] opciones =
                            {
                            new Vector2(distanciaMovimiento, 0),
                            new Vector2(-distanciaMovimiento, 0),
                            new Vector2(0, distanciaMovimiento),
                            new Vector2(0, -distanciaMovimiento)
                            };

                            Vector2 mejorMovimiento = Vector2.Zero;
                            float mejorDistancia = float.MaxValue;

                            foreach (Vector2 opcion in opciones)
                            {
                                Rectangle posibleBounds = new Rectangle(
                                    (int)(_posicionErizo.X + opcion.X),
                                    (int)(_posicionErizo.Y + opcion.Y),
                                    _cuerpoErizo.Bounds.Width,
                                    _cuerpoErizo.Bounds.Height
                                );

                                bool libre =
                                    limitesMapa.Contains(posibleBounds) &&
                                    !posibleBounds.Intersects(_cuerpoRana.Bounds) &&
                                    !posibleBounds.Intersects(_cuerpoHeroe1.Bounds) &&
                                    (_numeroJugadores != 2 ||
                                    !posibleBounds.Intersects(_cuerpoHeroe2.Bounds));

                                if (libre)
                                {
                                    Vector2 posiblePosicion = _posicionErizo + opcion;
                                    float distancia = Vector2.Distance(
                                        posiblePosicion, objetivo);

                                    if (distancia < mejorDistancia)
                                    {
                                        mejorDistancia = distancia;
                                        mejorMovimiento = opcion;
                                    }
                                }
                            }

                            if (mejorMovimiento != Vector2.Zero)
                            {
                                if (_numeroJugadores == 2)
                                    _cuerpoErizo.Move(mejorMovimiento, _cuerpoHeroe1, _cuerpoHeroe2, _cuerpoRana);
                                else
                                    _cuerpoErizo.Move(mejorMovimiento, _cuerpoHeroe1, _cuerpoRana);
                            }
                        }

                        else if (chocoH1 || chocoH2)
{
    // Daño al jugador 1
    if (chocoH1 && !tocandoErizoHeroe1)
    {
        _jugador1._vidaJugadores.QuitarVida(1);
        tocandoErizoHeroe1 = true;
    }

    // Daño al jugador 2
    if (chocoH2 && !tocandoErizoHeroe2)
    {
        _jugador2._vidaJugadores.QuitarVida(1);
        tocandoErizoHeroe2 = true;
    }

    // Se aleja del jugador
    Vector2 heroe = chocoH1 ? _posicionHeroe1 : _posicionHeroe2;
    direccionRetrocesoErizo = _posicionErizo - heroe;

    if (direccionRetrocesoErizo != Vector2.Zero)
        direccionRetrocesoErizo.Normalize();

    erizoEnPausa = true;
    tiempoPausaErizo = 1.5f;
}
                        else
                        {
                            // persigue alheroe 
                            if (_numeroJugadores == 2)
                                _cuerpoErizo.Move(movimiento, _cuerpoHeroe1, _cuerpoHeroe2, _cuerpoRana);
                            else
                                _cuerpoErizo.Move(movimiento, _cuerpoHeroe1, _cuerpoRana);
                        }

                        _posicionErizo = _cuerpoErizo.Position;
                    }
                    // Límites del recorrido

                    if (_posicionErizo.X >= 550) direccionErizo.X = -1;
                    if (_posicionErizo.X <= 50) direccionErizo.X = 1;

                    if (_posicionErizo.Y >= 550) direccionErizo.Y = -1;
                    if (_posicionErizo.Y <= 50) direccionErizo.Y = 1;
                }

                if (mostrarEnemigo == true)
                {
                    float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
                    tiempoMovimientoRana += deltaTime;

                    if (tiempoMovimientoRana >= intervaloMovimientoRana && !ranaSaltando)
                    {
                        tiempoMovimientoRana = -2.2f;

                        //buscar heroe cerca

                        Vector2 objetivo = _posicionHeroe1;

                        if (_numeroJugadores == 2)
                        {
                            float distanciaH1 = Vector2.Distance(_posicionRana, _posicionHeroe1);
                            float distanciaH2 = Vector2.Distance(_posicionRana, _posicionHeroe2);

                            if (distanciaH2 < distanciaH1)
                                objetivo = _posicionHeroe2;
                        }

                        int baldosa = 32;
                        Vector2[] movimientos =
                                    {
                            new Vector2 (baldosa * 2, baldosa),
                            new Vector2 (baldosa * 2, -baldosa),
                            new Vector2(-baldosa * 2,  baldosa),
                            new Vector2(-baldosa * 2, -baldosa),

                            new Vector2 (baldosa, baldosa * 2),
                            new Vector2 (baldosa, -baldosa * 2),
                            new Vector2 (-baldosa, baldosa * 2),
                            new Vector2 (-baldosa, -baldosa * 2)
                        };
                        Vector2 mejorPosicion = _posicionRana;
                        float mejorDistancia = Vector2.Distance(_posicionRana, objetivo);
                        foreach (Vector2 movimiento in movimientos)
                        {
                            Vector2 posiblePosicion = _posicionRana + movimiento;

                            Rectangle posibleBounds = new Rectangle(
                             (int)posiblePosicion.X,
                             (int)posiblePosicion.Y,
                             _cuerpoRana.Bounds.Width,
                            _cuerpoRana.Bounds.Height
                           );
                            float distancia = Vector2.Distance(posiblePosicion, objetivo);

                            bool chocaHeroe1 = posibleBounds.Intersects(_cuerpoHeroe1.Bounds);
                            bool chocaErizo = posibleBounds.Intersects(_cuerpoErizo.Bounds);
                            bool chocaHeroe2 = _numeroJugadores == 2 &&
                                   posibleBounds.Intersects(_cuerpoHeroe2.Bounds);

                            // acepta movimientos dentro del mapa y q no atraviesen heroes
                           if (limitesMapa.Contains(posibleBounds) && !chocaErizo && distancia < mejorDistancia)
                            {
                                mejorDistancia = distancia;
                                mejorPosicion = posiblePosicion;
                            }
                        }

                        // Actualiza la posición de la rana
                        if (mejorPosicion != _posicionRana)
                        {
                            inicioSaltoRana = _posicionRana;
                            destinoRana = mejorPosicion;

                            tiempoAnimacionRana = 0f;
                            ranaSaltando = true;

                            tiempoMovimientoRana = -2.2f;
                        }
                    }
                }
                if (mostrarEnemigo && ranaSaltando)
                {
                    float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

    tiempoAnimacionRana += deltaTime;
    _animacionRanaAterriza.Update(gameTime);

    // Movimiento del salto
    float progreso = MathHelper.Clamp(
        tiempoAnimacionRana / duracionSaltoRana, 0f, 1f);

    _posicionRana = Vector2.Lerp(
        inicioSaltoRana, destinoRana, progreso);

    _cuerpoRana.SetPosition(_posicionRana);

    if (tiempoAnimacionRana >= duracionSaltoRana)
    {
        // Aterriza
        _posicionRana = destinoRana;
        _cuerpoRana.SetPosition(_posicionRana);

        bool recibioDanio = false;

        // Comprueba si tocó al jugador 1
        if (_cuerpoRana.Bounds.Intersects(_cuerpoHeroe1.Bounds))
        {
            _jugador1._vidaJugadores.QuitarVida(2);
            recibioDanio = true;
        }

        // Comprueba si tocó al jugador 2
        if (_numeroJugadores == 2 &&
            _cuerpoRana.Bounds.Intersects(_cuerpoHeroe2.Bounds))
        {
            _jugador2._vidaJugadores.QuitarVida(2);
            recibioDanio = true;
        }

        // Si hizo daño, busca una posición libre
        if (recibioDanio)
        {
            int baldosa = 32;

            Vector2[] opciones =
            {
                new Vector2(64, 32),
                new Vector2(64, -32),
                new Vector2(-64, 32),
                new Vector2(-64, -32),
                new Vector2(32, 64),
                new Vector2(32, -64),
                new Vector2(-32, 64),
                new Vector2(-32, -64)
            };

            foreach (Vector2 opcion in opciones)
            {
                Vector2 posiblePosicion = _posicionRana + opcion;

                Rectangle posibleBounds = new Rectangle(
                    (int)posiblePosicion.X,
                    (int)posiblePosicion.Y,
                    _cuerpoRana.Bounds.Width,
                    _cuerpoRana.Bounds.Height
                );

                bool libre =
                    limitesMapa.Contains(posibleBounds) &&
                    !posibleBounds.Intersects(_cuerpoHeroe1.Bounds) &&
                    !posibleBounds.Intersects(_cuerpoErizo.Bounds) &&
                    (_numeroJugadores != 2 ||
                    !posibleBounds.Intersects(_cuerpoHeroe2.Bounds));

                if (libre)
                {
                    _posicionRana = posiblePosicion;
                    _cuerpoRana.SetPosition(_posicionRana);
                    break;
                }
            }
        }

        ranaSaltando = false;
        tiempoMovimientoRana = -2.2f;
    }
                }
                rectanguloHeroe1.X = (int)_posicionHeroe1.X;
                rectanguloHeroe1.Y = (int)_posicionHeroe1.Y;

                rectanguloHeroe2.X = (int)_posicionHeroe2.X;
                rectanguloHeroe2.Y = (int)_posicionHeroe2.Y;

                rectanguloErizo.X = (int)_posicionErizo.X;
                rectanguloErizo.Y = (int)_posicionErizo.Y;
                _cuerpoHeroe1.SetPosition(_posicionHeroe1);
                _cuerpoHeroe2.SetPosition(_posicionHeroe2);
                _cuerpoErizo.SetPosition(_posicionErizo);
                _cuerpoRana.SetPosition(_posicionRana);
                
                break;

                //PAUSAR EL JUEGO
                case EstadoJuego.Pausado:

    _uiManager.Update(gameTime, 3);

    if (_uiManager.Confirmar)
    {
        switch (_uiManager.SelectedIndex)
        {
            case 0:
                // CONTINUAR
                _estadoActual = EstadoJuego.Jugando;
                break;

            case 1:
                // OPCIONES
                _estadoAnteriorOpciones = EstadoJuego.Pausado;
                _estadoActual = EstadoJuego.Opciones;
                _uiManager.ReiniciarSeleccion();
                break;

            case 2:
                // VOLVER AL MENU
                _estadoActual = EstadoJuego.MenuPrincipal;
                _uiManager.ReiniciarSeleccion();
                break;
        }
    }

    break;
    case EstadoJuego.Opciones:

    _uiManager.Update(gameTime, 1);

    if (_uiManager.Confirmar)
    {
        _estadoActual = _estadoAnteriorOpciones;
        _uiManager.ReiniciarSeleccion();
    }

    break;
        }
        // TODO: Add your update logic here

        
_tecladoAnterior = tecladoActual;

        base.Update(gameTime);
    }


    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);


        // Begin the sprite batch to prepare for rendering.
        SpriteBatch.Begin(samplerState: SamplerState.PointWrap);

        if (_estadoActual == EstadoJuego.MenuPrincipal)
        {


            //pantalla inicio
            float escalaXTitulo = (float)Window.ClientBounds.Width / pantallaInicial.Width;
            float escalaYTitulo = (float)Window.ClientBounds.Height / pantallaInicial.Height;
            SpriteBatch.Draw(
                            pantallaInicial,
                            Vector2.Zero,
                            null,
                            Color.White,
                            0,
                            Vector2.Zero,
                            new Vector2(escalaXTitulo, escalaYTitulo),
                            SpriteEffects.None,
                            0.0f
                        );


            _uiManager.DrawMenuPrincipal(SpriteBatch);
        }

        else if (_estadoActual == EstadoJuego.SeleccionJugadores)
        {

            GraphicsDevice.Clear(Color.DarkSlateGray);

            _uiManager.DrawSeleccionJugadores(SpriteBatch);

        }
        else if (_estadoActual == EstadoJuego.Opciones &&
         _estadoAnteriorOpciones == EstadoJuego.MenuPrincipal)
{
    SpriteBatch.Draw(
        pantallaInicial,
        Vector2.Zero,
        Color.White
    );

    _uiManager.DrawOpciones(SpriteBatch);
}
       else if (
    _estadoActual == EstadoJuego.Jugando || _estadoActual == EstadoJuego.Pausado ||(_estadoActual == EstadoJuego.Opciones &&  _estadoAnteriorOpciones == EstadoJuego.Pausado))
        {
            _tileMap.Draw(SpriteBatch);
            TextureRegion frameHeroe1 = _animacionesHeroe1[_estadoAnimacionHeroe1].CurrentFrame;

            float origenX = _animacionesHeroe1[_estadoAnimacionHeroe1].CurrentFrame.Width * 0.5f;
            float origenY = _animacionesHeroe1[_estadoAnimacionHeroe1].CurrentFrame.Height * 0.5f;
            frameHeroe1.Draw(
                SpriteBatch,
                new Vector2(_posicionHeroe1.X, _posicionHeroe1.Y),
                Color.White,
                0f,
                Vector2.Zero,
                new Vector2(3f, 3f),
                SpriteEffects.None,
                0f);

            if (_numeroJugadores == 2)
            {

                TextureRegion frameHeroe2 = _animacionesHeroe2[_estadoAnimacionHeroe2].CurrentFrame;
                frameHeroe2.Draw(
                   SpriteBatch,
                   new Vector2(_posicionHeroe2.X, _posicionHeroe2.Y),
                   Color.White,
                   0f,
                   Vector2.Zero,
                   new Vector2(3f, 3f),
                   SpriteEffects.None,
                   0f);
            }
                               // Dibujar vidas del jugador 1
_jugador1.DibujarVida(
    SpriteBatch,
    new Vector2(20, 15)
);
            

// Dibujar vidas del jugador 2 solamente si está jugando
// una partida de dos jugadores
if (_numeroJugadores == 2)
{
    _jugador2.DibujarVida(
        SpriteBatch,
        new Vector2(672, 15)
    );
  
}


            if (mostrarEnemigo == true)
            {
                _regionErizoFrente.Draw(
                    SpriteBatch,
                    new Vector2(_posicionErizo.X, _posicionErizo.Y),
                    Color.White,
                    0f,
                    Vector2.Zero,
                    new Vector2(2f, 2f),
                    SpriteEffects.None,
                    0f);


                TextureRegion frameRana;

                if (ranaSaltando)
                {
                    frameRana = _animacionRanaAterriza.CurrentFrame;
                }
                else
                {
                    frameRana = _animacionRanaSalto.CurrentFrame;
                }
                frameRana.Draw(
                    SpriteBatch,
                    _posicionRana,
                    Color.White,
                    0f,
                    Vector2.Zero,
                    new Vector2(2f, 2f),
                    SpriteEffects.None,
                    0f);
 
            }
            if (_estadoActual == EstadoJuego.Pausado)
{
    _uiManager.DrawMenuPausa(SpriteBatch);
}
else if (_estadoActual == EstadoJuego.Opciones &&
         _estadoAnteriorOpciones == EstadoJuego.Pausado)
{
    _uiManager.DrawOpciones(SpriteBatch);
}

        }




        // Always end the sprite batch when finished.
        SpriteBatch.End();

        base.Draw(gameTime);
    }
}
