using System;
using Microsoft.Xna.Framework;
using MonoGameLibrary.Graphics;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using MonoGameLibrary.Physics;

namespace The_ancient_s_wizard_dungeon
{
    


public class Jugador
{
    public VidaJugadores _vidaJugadores;

    public int _puntuacion;
    public bool invulnerable = false;
    private CollisionBody _cuerpo;
public CollisionBody Cuerpo { get; private set; }
private int _alcanceAtaque = 24;
       private float duracionInvulnerabilidad = 1.3f;
    private float tiempoInvulnerabilidad = 0f;

public bool estaVivo=true;
    private Vector2 _posicion;
    

    public Jugador(Texture2D texturaVida, CollisionBody cuerpo){
            _vidaJugadores = new VidaJugadores(texturaVida);
            _puntuacion = 0;
           Cuerpo = cuerpo;

        }
        public void DibujarVida(SpriteBatch spriteBatch, Vector2 posicion)
        {
            _vidaJugadores.Dibujar(spriteBatch,posicion);
        }
        public void muere()
        {
            estaVivo = false;

        }
        public void Revivir()
{
    estaVivo = true;
    _vidaJugadores.ReiniciarVida();
}
}



}