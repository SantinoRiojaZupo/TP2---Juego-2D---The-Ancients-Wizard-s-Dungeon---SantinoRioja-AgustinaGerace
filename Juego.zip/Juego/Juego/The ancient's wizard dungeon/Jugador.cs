using System;
using Microsoft.Xna.Framework;
using MonoGameLibrary.Graphics;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;

namespace The_ancient_s_wizard_dungeon
{
    


public class Jugador
{
    public VidaJugadores _vidaJugadores;

    public int _puntuacion;

    private Vector2 _posicion;

    public Jugador(Texture2D texturaVida, Vector2 posicionInicial){
            _vidaJugadores = new VidaJugadores(texturaVida);
            _puntuacion = 0;
            _posicion = posicionInicial;

        }
        public void DibujarVida(SpriteBatch spriteBatch, Vector2 posicion)
        {
            _vidaJugadores.Dibujar(spriteBatch,posicion);
        }
}



}